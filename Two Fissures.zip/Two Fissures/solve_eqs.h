#ifndef SOLVE_EQS_H
#define SOLVE_EQS_H

#include<vector>
#include<cmath>
#include<complex>
#include<armadillo>;

std::vector<double> find_ratio_roots(double k, double start, double end,
    double h, double eps, double max_step);

arma::cx_vec find_complex_roots(double start, double end, int max_steps = 200, double h = 0.1, int k = 5, double eps = 0.0001);

double rungeKutta1(double alpha, double x0, double U1_0, double Sigma1_0, double x_end, double k = 5, double h = 0.001);
arma::cx_double rungeKutta3(double x0, double U2_0, double sigma2_0, double U2_alpha_0, double sigma2_alpha_0, double x, double h, arma::cx_double alpha, double k);


#endif // !
