#ifndef FIND_FISSURES_H
#define FIND_FISSURES_H
#include <complex>;
#include <vector>;
#include <math.h>;
#include <armadillo>;
#include <omp.h>;

using std::vector; using std::complex; using arma::mat; using arma::vec; using arma::cx_vec;

class Fissures {

public:
	double l1, d1, l2, d2, k30;
	int N, k, p;
	vec t;
	vec t0;

	void fill_t();
	void fill_Ac(mat* A11, mat* A21, mat* A12);
	void fill_Areg(mat* A11, mat* A21, mat* A12, mat* A22);
	void fill_F(vector<complex<double>>* F1, vector<complex<double>>* F2);
	double k3reg(double x1, double x2, vec k3_integral, double h);
	double k3(double alpha);

	Fissures();
	Fissures(double l1, double l2, double d1, double d2, int N = 20, int k = 5, int p = 1);
	void set_coordinates(double l1, double d1, double l2, double d2);

	cx_vec solve_xi();
	double solve_k30();
};


#endif // !FIND_FISSURES_H