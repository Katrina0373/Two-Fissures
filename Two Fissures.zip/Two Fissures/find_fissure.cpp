#include"find_fissure.h"
#include"solve_eqs.h"
#include<iostream>
#include<chrono>

using std::complex; using std::vector; using std::cout; using std::endl;
using namespace arma;
using namespace std::complex_literals;


double (*mu)(double) = { [](double x) {return
		1 + std::pow(x, 2) / 10; } };


void Fissures::fill_Ac(mat* A11, mat* A21, mat* A12) {
	
	A11->clear();
	A21->clear();
	A12->clear();
	A11->resize(N, N);
	A21->resize(N, N);
	A12->resize(N, N);

	//auto start_time = std::chrono::high_resolution_clock::now();

	for (size_t i = 0; i < N; i++)
	{
#pragma omp parallel
		{
#pragma omp for
			for (int j = 0; j < N; j++)
			{
				(*A11)(i, j) = 2 * k30 * (1 / (t[i + 1] - t0[j]) - 1 / (t[i] - t0[j]));

				(*A21)(i, j) = 2 * k30 * (
					1 / (d2 + l2 * t[i + 1] - d1 - l1 * t0[j]) -
					1 / (d2 + l2 * t[i] - d1 - l1 * t0[j]));

				(*A12)(i, j) = 2 * k30 * (
					1 / (d1 + l1 * t[i + 1] - d2 - l2 * t0[j]) -
					1 / (d1 + l1 * t[i] - d2 - l2 * t0[j]));

			}
		}
	}

	//auto end_time = std::chrono::high_resolution_clock::now();
	//std::chrono::duration<double> duration = end_time - start_time;
	//std::cout << "����� ��� ���������� ������� ��: " << duration.count() << std::endl;
}

void Fissures::fill_Areg(mat* A11, mat* A21, mat* A12, mat* A22) {
	
	double h = 0.01;
	double alphaM = 600;
	size_t steps = alphaM / h;
	vector<double> k3_integral(steps);

	//auto start_time = std::chrono::high_resolution_clock::now();

#pragma omp parallel
	{
#pragma omp for
		for (size_t i = 0; i < steps; i++)
		{
			k3_integral[i] = k3(h / 2 + i * h);
		}
	}
	/*auto end_time = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> duration = end_time - start_time;
	std::cout << "����� ���������� k3_integral: " << duration.count() << std::endl;*/

	A11->clear();
	A21->clear();
	A12->clear();
	A22->clear();
	A11->resize(N, N);
	A21->resize(N, N);
	A12->resize(N, N);
	A22->resize(N, N);


	//start_time = std::chrono::high_resolution_clock::now();

	for (size_t i = 0; i < N; i++)
	{
#pragma omp parallel
		{
#pragma omp for
			for (int j = 0; j < N; j++)
			{
				double integral = k3reg(
					l1 * (t[i + 1] - t0[j]),
					l1 * (t[i] - t0[j]),
					k3_integral, h);
				//std::cout << "�������� ���������: " << integral << std::endl;
				(*A11)(i, j) = integral;

				(*A21)(i, j) = k3reg(
					d2 + l2 * t[i + 1] - d1 - l1 * t0[j],
					d2 + l2 * t[i] - d1 - l1 * t0[j],
					k3_integral, h);

				(*A12)(i, j) = k3reg(
					d1 + l1 * t[i + 1] - d2 - l2 * t0[j],
					d1 + l1 * t[i] - d2 - l2 * t0[j],
					k3_integral, h);

				(*A22)(i, j) = k3reg(
					l2 * (t[i + 1] - t0[j]),
					l2 * (t[i] - t0[j]),
					k3_integral, h);
			}
		}
	}

	//end_time = std::chrono::high_resolution_clock::now();
	//duration = end_time - start_time;
	//std::cout << "����� ���������� ������� Areg: " << duration.count() << std::endl;
}


void Fissures::fill_F(vector<complex<double>>* F1, vector<complex<double>>* F2) {

	F1->clear();
	F2->clear();


	//auto start_time = std::chrono::high_resolution_clock::now();

	vec roots_sigma2re(find_ratio_roots(k, 0, 100, 0.1, 1.0e-8, 1000));
	cx_vec roots_sigma2(roots_sigma2re.size());
	for (size_t i = 0; i < roots_sigma2re.size(); i++)
	{
		roots_sigma2(i) = cx_double(roots_sigma2re[i], 0);
	}
	roots_sigma2 = join_cols(roots_sigma2, find_complex_roots(0, 100, 300, 0.1, k, 1.0e-8));


	//auto end_time = std::chrono::high_resolution_clock::now();
	//std::chrono::duration<double> duration = end_time - start_time;
	//std::cout << "����� ���������� ������: " << duration.count() << std::endl;

	int N1 = roots_sigma2.size();

	F1->resize(N);
	F2->resize(N);

	auto F = [N1, roots_sigma2, this](double x) {
		cx_double sum = 0;
		double sign = x > 0 ? 1 : -1;

		for (size_t i = 0; i < N1 - 1; i++)
		{	
			sum += exp(roots_sigma2[i] * abs(x)*1.i) /
				rungeKutta3(0, 0, 1, 0, 0, 1, 1.0e-5, -sign * roots_sigma2[i], k);
		}

		return sign * p * 2 * 3.14 * sum * 1.i;
	};
	//start_time = std::chrono::high_resolution_clock::now();
#pragma omp parallel
	{
#pragma omp for
		for (int i = 0; i < N; i++)
		{
			double x1 = d1 + l1 * t0[i];
			double x2 = d2 + l2 * t0[i];
			(*F1)[i] = F(x1);
			(*F2)[i] = F(x2);
			//cout << (*F1)(i) << " " << (*F2)(i) << endl;
		}
	}

	//end_time = std::chrono::high_resolution_clock::now();
	//duration = end_time - start_time;
	//std::cout << "����� ���������� F1 F2: " << duration.count() << std::endl;
}

//double Fissures::k3reg(double x1, double x2, vec k3_integral, double h) {
//	
//	double integral = 0;
//	auto Dij = [x1, x2, k3_integral, this](double alpha, size_t i) {
//		return (k3_integral[i] - k30 * abs(alpha)) / alpha *		//� ������ ����������� ��������� k3(alpha, 0) ����������� ��������
//			(sin(alpha * x1) - sin(alpha * x2));
//	};
//	for (size_t i = 0; i < k3_integral.size(); i++)
//	{
//		integral += Dij(h / 2 + h * i, i);
//	}
//
//	return 2 * h * integral;
//}

double Fissures::k3reg(double y1, double y2, vec k3_integral, double width) {

	auto Dij = [y1, y2, k3_integral, this](double alpha, int i) {
		return (k3_integral[i] - k30 * abs(alpha)) / alpha *		//� ������ ����������� ��������� k3(alpha, 0) ����������� ��������
			(sin(alpha * y1) - sin(alpha * y2));
	};

	double simpson_integral = 0;
	for (int step = 0; step < k3_integral.size(); step++) {
		const double x1 = width/2 + step * width;
		const double x2 = width/2+ (step + 1) * width;

		simpson_integral += (x2 - x1) / 6.0 * (Dij(x1, step) + 4.0 * Dij(0.5 * (x1 + x2), step) + Dij(x2, step));
	}

	return simpson_integral;
}

//x = 0
double Fissures::k3(double alpha) {
	double sigma1 = rungeKutta1(alpha, 0, 1, 0, 1, k, 0.0001);
	double sigma2 = rungeKutta1(alpha, 0, 0, 1, 1, k, 0.0001);
	return -sigma1 / sigma2;
}

cx_vec Fissures::solve_xi()
{
	mat Ac11, Ac12, Ac21, Ac22;
	vector<complex<double>> F1, F2;
	mat Areg11, Areg12, Areg21, Areg22;

	fill_Ac(&Ac11, &Ac21, &Ac12);
	fill_Areg(&Areg11, &Areg12, &Areg21, &Areg22);
	fill_F(&F1, &F2);
	


	Ac22 = Ac11;
	cx_mat A(2*N, 2*N, fill::zeros);
	cx_vec B(2*N);
	// ����������� � ������� �
	for (size_t i = 0; i < N; i++)
	{
		for (size_t j = 0; j < N; j++)
		{
			A(i, j) = Ac11[j, i] / l1 + l1 * Areg11[j, i]; 
			A(i, N + j) = l2 * Ac21[j, i] + l2 * Areg21[j, i];
			A(i + N, j) = l1 * Ac12[j, i] + l1 * Areg12[j, i];
			A(i + N, j + N) = Ac22[j, i] / l2 + l2 * Areg22[j, i];
		}
		B(i) = F1[i];
		B(i + N) = F2[i];
	}
	auto xi = solve(A, B);

	return xi;
}

double Fissures::solve_k30() {
	//����������� alfa ��������
	int alpha = 400;
	return k3(alpha) / alpha;
}

void Fissures::fill_t()
{
	t = linspace(-1, 1, N+1);
	t0 = linspace((t[0] + t[1]) / 2, (t[N] + t[N - 1]) / 2, N);
}

Fissures::Fissures()
{
	l1 = 0.1; l2 = 0.1;
	d1 = 0.5; d2 = 1;
	N = 20; k = 5; p = 1;
	fill_t();
	k30 = k3(400);
}

Fissures::Fissures(double l1, double l2, double d1, double d2, int N, int k, int p)
{
	this->l1 = l1;
	this->l2 = l2;
	this->d1 = d1;
	this->d2 = d2;
	this->k = k;
	this->N = N;
	this->p = p;
	fill_t();
	k30 = solve_k30();
}

void Fissures::set_coordinates(double l1, double d1, double l2, double d2)
{
	this->l1 = l1;
	this->l2 = l2;
	this->d1 = d1;
	this->d2 = d2;
}
